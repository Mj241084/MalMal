"""Geo application configuration."""

from __future__ import annotations

from django.apps import AppConfig


class GeoConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.geo"
    verbose_name = "استان و شهر"
