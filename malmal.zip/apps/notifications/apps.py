"""SMS application configuration."""

from __future__ import annotations

from django.apps import AppConfig


class NotificationsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.notifications"
    verbose_name = "اعلان‌ها"

    def ready(self) -> None:
        from apps.notifications import checks  # noqa: F401
