"""Seed default SiteSettings singleton with store_name='مل‌مل'."""

from django.db import migrations


def seed_site_settings(apps, schema_editor):
    SiteSettings = apps.get_model("core", "SiteSettings")
    SiteSettings.objects.get_or_create(pk=1, defaults={"store_name": "مل‌مل"})


class Migration(migrations.Migration):
    dependencies = [
        ("core", "0001_initial"),
    ]

    operations = [
        migrations.RunPython(seed_site_settings, migrations.RunPython.noop),
    ]
